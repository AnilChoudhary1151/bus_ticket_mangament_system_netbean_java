/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package BmsFunctions;
import java.io.File;
import java.io.FileOutputStream;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.PdfWriter;
/**
 *
 * @author Admin
 */
public class apdfgenerate {
    
    public static void main(String[] args){
    String FILE_NAME = "C:\\Users\\Admin\\Desktop\\ticket.pdf";
        Document document = new Document();
        try {
            PdfWriter.getInstance(document, new FileOutputStream(new File(FILE_NAME)));
            document.open();
            Paragraph p = new Paragraph();
            
            p.add("HOLIDAY BUS SERVICE\n\n");
            p.add("****************************************************************");
            p.add("");
            p.add("Bus Ticket\n\n");
            p.add("****************************************************************");
            p.add("");
            p.setAlignment(Element.ALIGN_CENTER);
            document.add(p);
            Paragraph p1 = new Paragraph();
            Font g = new Font();
            g.setStyle(Font.BOLD);
            g.setSize(16);
            document.add(new Paragraph("Booking Details     \n", g));
            p1.add("Booking Id                       \n");
            p1.add("Bus Number                                 \n");
            p1.add("Seat number                                 \n");
            p1.add("Departure from                                \n");
            p1.add("Arrive to                                 \n");
            p1.add("Amount                                \n\n");
            
            document.add(p1);
            
            Paragraph p2 = new Paragraph();
            document.add(new Paragraph("Customer Details     \n", g));
            p2.add("Customer Name                       \n");
            p2.add("Age                                 \n");
            p2.add("Gender                                 \n");
            p2.add("Phone Number                                \n");
            document.add(p2);
            
            document.close();
            System.out.println("Done");
        } catch (Exception e) {
            e.printStackTrace();
        } }
}
